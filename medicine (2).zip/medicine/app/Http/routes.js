'use strict'

/*
|--------------------------------------------------------------------------
| Router
|--------------------------------------------------------------------------
|
| AdonisJs Router helps you in defining urls and their actions. It supports
| all major HTTP conventions to keep your routes file descriptive and
| clean.
|
| @example
| Route.get('/user', 'UserController.index')
| Route.post('/user', 'UserController.store')
| Route.resource('user', 'UserController')
*/

const Route = use('Route')

Route.get('/', 'MedicineController.index')
Route.get('/ownMedicines', 'MedicineController.ownList').middleware('auth')
Route.get('/medicines/create', 'MedicineController.create').middleware('auth')
Route.post('/medicines/create', 'MedicineController.doCreate').middleware('auth')
Route.get('/medicines/:id/edit', 'MedicineController.edit').middleware('auth')
Route.post('/medicines/:id/edit', 'MedicineController.doEdit').middleware('auth')
Route.get('/medicines/:id/delete', 'MedicineController.doDelete').middleware('auth')
Route.get('/medicines/:id', 'MedicineController.show')

Route.get('/register', 'UserController.register')
Route.get('/login', 'UserController.login')
Route.post('/register', 'UserController.doRegister')
Route.post('/login', 'UserController.doLogin')
Route.get('/logout', 'UserController.doLogout')
