'use strict'

const Database = use('Database')
const Store = use('App/Model/Store')
const Recipe = use('App/Model/Recipe')
const Category = use('App/Model/Category')
const Medicine = use('App/Model/Medicine')
const Validator = use('Validator')

class MedicineController {

  * index(request, response) {
    

    const categories = yield Category.all()
    

    for(let category of categories) {
      const medicines = yield category.medicines().fetch();
      category.topMedicines = medicines.toJSON();
    }

    yield response.sendView('main', {
      name: '',
      categories: categories.toJSON()
    })  

    const stores = yield Store.all()

    yield response.sendView('main', {
      name: '',
      stores: stores.toJSON()
    })  

    const recipes = yield Recipe.all()

    yield response.sendView('main', {
      name: '',
      Recipes: recipes.toJSON()
    }) 
  }

  * create (request, response) {
    const categories = yield Category.all()
    const stores = yield Store.all()
    const recipes = yield Recipe.all()
    yield response.sendView('medicineCreate', {
      categories: categories.toJSON(),
      stores: stores.toJSON(),
      recipes: recipes.toJSON()
    });

  }

  * doCreate (request, response) {
    const medicineData = request.except('_csrf');

    const rules = {
      name: 'required',
      instructions: 'required',
      category_id: 'required',
      store_id: 'required',
      recipe_id: 'required'
    };

    const validation = yield Validator.validateAll(medicineData, rules)

    if (validation.fails()) {
      yield request
        .withAll()
        .andWith({errors: validation.messages()})
        .flash()
      response.redirect('back')
      return
    }

    medicineData.user_id = request.currentUser.id
    const medicine = yield Medicine.create(medicineData)
    
    response.redirect('/')
  }

  * edit (request, response) {
    const categories = yield Category.all()
    const id = request.param('id');
    const medicine = yield Medicine.find(id);
    const stores = yield Store.all();
    const recipes = yield Recipe.all();

    if (request.currentUser.id !== medicine.user_id) {
      response.unauthorized('Belépés megtagadva')
      return
    }


    yield response.sendView('medicineEdit', {
      categories: categories.toJSON(),
      stores: stores.toJSON(),
      recipes: recipes.toJSON(),
      medicine: medicine.toJSON()
    });
  }

  * doEdit (request, response) {
    const medicineData = request.except('_csrf');

    const rules = {
      name: 'required',
      instructions: 'required',
      category_id: 'required',
      store_id: 'required',
      recipe_id: 'required'
    };

    const validation = yield Validator.validateAll(medicineData, rules)

    if (validation.fails()) {
      yield request
        .withAll()
        .andWith({errors: validation.messages()})
        .flash()
      response.redirect('back')
      return
    }

    const id = request.param('id');
    const medicine = yield Medicine.find(id);

    
    
    medicine.name = medicineData.name;
    medicine.instructions = medicineData.instructions;
    medicine.category_id = medicineData.category_id;
    medicine.store_id = medicineData.store_id;
    medicine.recipe_id = medicineData.recipe_id;

    yield medicine.save()
    
    response.redirect('/')
  }

  * show (request, response) {
    const id = request.param('id');
    const medicine = yield Medicine.find(id);
    yield medicine.related('category').load();
    yield medicine.related('store').load();
    yield medicine.related('recipe').load();
    yield response.sendView('medicineShow', {
      medicine: medicine.toJSON()
    })
  }

  * doDelete (request, response) {
    const id = request.param('id');
    const medicine = yield Medicine.find(id);

    if (request.currentUser.id !== medicine.user_id) {
      response.unauthorized('Belépés megtagadva')
      return
    }

    yield medicine.delete()
    response.redirect('/')
  }
  
}

module.exports = MedicineController
