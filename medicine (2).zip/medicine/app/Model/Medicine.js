'use strict'

const Lucid = use('Lucid')

class Medicine extends Lucid {
  category () {
    return this.belongsTo('App/Model/Category')
  }

  store () {
    return this.belongsTo('App/Model/Store')
  }

  recipe () {
    return this.belongsTo('App/Model/Recipe')
  }

}

module.exports = Medicine
