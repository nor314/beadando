'use strict'

const Lucid = use('Lucid')

class Store extends Lucid {
    medicines () {
    return this.hasMany('App/Model/Medicine')
  }
}

module.exports = Store
