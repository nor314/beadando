'use strict'

const Schema = use('Schema')

class StoresTableSchema extends Schema {

  up () {
    this.create('stores', (table) => {
      table.increments()
      table.string('name', 20).notNullable().unique()
      table.timestamps()
    })
  }

  down () {
    this.drop('stores')
  }

}

module.exports = StoresTableSchema
