'use strict'

const Schema = use('Schema')

class MedicinesTableSchema extends Schema {

  up () {
    this.create('medicines', (table) => {
      table.increments()
      table.string('name').notNullable() 
      table.text('instructions').notNullable()
      table.integer('user_id').unsigned().references('id').inTable('users')
      table.integer('category_id').unsigned().references('id').inTable('categories')
      table.integer('store_id').unsigned().references('id').inTable('stores')
      table.integer('recipe_id').unsigned().references('id').inTable('recipes')
      table.timestamps()
    })
  }

  down () {
    this.drop('medicines')
  }

}

module.exports = MedicinesTableSchema
