'use strict'

const Database = use('Database')
const Category = use('App/Model/Category')
const Medicine = use('App/Model/Medicine')
const Validator = use('Validator')

class MedicineController {

  * index(request, response) {
    

    const categories = yield Category.all()

    for(let category of categories) {
      const medicines = yield category.medicines().limit(3).fetch();
      category.topMedicines = medicines.toJSON();
    }

    yield response.sendView('main', {
      name: '',
      categories: categories.toJSON()
    })  
  }

  * create (request, response) {
    const categories = yield Category.all()
    yield response.sendView('medicineCreate', {
      categories: categories.toJSON()
    });
  }

  * doCreate (request, response) {
    const medicineData = request.except('_csrf');

    const rules = {
      name: 'required',
      
      instructions: 'required',
      category_id: 'required'
    };

    const validation = yield Validator.validateAll(medicineData, rules)

    if (validation.fails()) {
      yield request
        .withAll()
        .andWith({errors: validation.messages()})
        .flash()
      response.redirect('back')
      return
    }

    medicineData.user_id = request.currentUser.id
    const medicine = yield Medicine.create(medicineData)
    
    response.redirect('/')
  }

  * edit (request, response) {
    const categories = yield Category.all()
    const id = request.param('id');
    const medicine = yield Medicine.find(id);
    

    if (request.currentUser.id !== medicine.user_id) {
      response.unauthorized('Access denied.')
      return
    }


    yield response.sendView('medicineEdit', {
      categories: categories.toJSON(),
      medicine: medicine.toJSON()
    });
  }

  * doEdit (request, response) {
    const medicineData = request.except('_csrf');

    const rules = {
      name: 'required',
      
      instructions: 'required',
      category_id: 'required'
    };

    const validation = yield Validator.validateAll(medicineData, rules)

    if (validation.fails()) {
      yield request
        .withAll()
        .andWith({errors: validation.messages()})
        .flash()
      response.redirect('back')
      return
    }

    const id = request.param('id');
    const medicine = yield Medicine.find(id);

    
    
    medicine.name = medicineData.name;
    
    medicine.instructions = medicineData.instructions;
    medicine.category_id = medicineData.category_id;

    yield medicine.save()
    
    response.redirect('/')
  }

  * show (request, response) {
    const id = request.param('id');
    const medicine = yield Medicine.find(id);
    yield medicine.related('category').load();
    

    yield response.sendView('medicineShow', {
      medicine: medicine.toJSON()
    })
  }

  * doDelete (request, response) {
    const id = request.param('id');
    const medicine = yield Medicine.find(id);

    if (request.currentUser.id !== medicine.user_id) {
      response.unauthorized('Access denied.')
      return
    }

    yield medicine.delete()
    response.redirect('/')
  }
  
}

module.exports = MedicineController
