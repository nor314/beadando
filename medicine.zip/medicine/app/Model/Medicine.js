'use strict'

const Lucid = use('Lucid')

class Medicine extends Lucid {
     category () {
    return this.belongsTo('App/Model/Category')
  }
}

module.exports = Medicine
